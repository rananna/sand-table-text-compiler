
Font name: Hershey Script 1-stroke smooth

Originally prepared in 2011 and converted to SVG fonts
in 2019 by Windell H. Oskay, www.evilmadscientist.com
Smoothed by Ellen Wasbo, http:\\cutlings.wasbo.net in 2020
The ttf and otf font is a stickfont - if used with a plotter the lines will be
drawn twice. otf will give less nodes.

Contents adapted from emergent.unpythonic.net/software/hershey
 by way of "Hershey Fonts in SVG" by Marty McGuire
 http://www.thingiverse.com/thing:6168
 
-------------------------------------------------------------------
The Hershey Fonts are a set of vector fonts with a liberal license.

USE RESTRICTION:
    This distribution of the Hershey Fonts may be used by anyone for
    any purpose, commercial or otherwise, providing that:
        1. The following acknowledgements must be distributed with
            the font data:
            - The Hershey Fonts were originally created by Dr.
                A. V. Hershey while working at the U. S.
                National Bureau of Standards.
            - The format of the Font data in this distribution
                was originally created by
                    James Hurt
                    Cognition, Inc.
                    900 Technology Park Drive
                    Billerica, MA 01821
                    (mit-eddie!ci-dandelion!hurt)
        2. The font data in this distribution may be converted into
            any other format *EXCEPT* the format distributed by
            the U.S. NTIS where each point is described
            in eight bytes as "xxx yyy:", where xxx and yyy are
            the coordinate values as ASCII numbers.
			
--------------------------------------------------------------------

The svg file contain glyph tables following the SVG 1.1 format http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd
These files are ment to be used in Inkscape as single line or stroke font together with the Hershey Text extension
or the Custom Stroke Fonts extension.
Nothing will show up if you try to display the svg file in a browser or in vector grafics software like Inkscape
as the paths of the glyphs are hidden in the xml code.